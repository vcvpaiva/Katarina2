package sem.graph.vetypes;

import java.io.Serializable;

import sem.graph.EdgeContent;


/**
 * The {@link EdgeContent} of a {@link RoleEdge}
 *
 */
public class RoleEdgeContent implements EdgeContent, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4131436743572513659L;

}
