package sem.graph.vetypes;

import java.io.Serializable;

import sem.graph.NodeContent;

/**
 * The {@link NodeContent} of a {@link ValueNode}
 *
 */
public class DistributionalNodeContent extends NodeContent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1277963016411600958L;



}

