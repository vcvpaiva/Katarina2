package sem.graph.vetypes;

import java.io.Serializable;

import sem.graph.NodeContent;



/**
 * The {@link NodeContent} of a {@link ValueNode}
 *
 */
public class ValueNodeContent extends NodeContent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 186924901917739484L;

}
