package sem.graph.vetypes;

import java.io.Serializable;

/**
 * The {@link NodeContent} for a {@link ContextNode}
 *
 */
public class ContextNodeContent extends TermNodeContent  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4031107264628807613L;


}
