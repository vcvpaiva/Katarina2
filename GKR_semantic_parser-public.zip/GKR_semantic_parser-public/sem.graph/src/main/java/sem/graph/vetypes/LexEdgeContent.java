package sem.graph.vetypes;

import java.io.Serializable;

import sem.graph.EdgeContent;

/**
 * The {@link EdgeContent} for {@link LexEdge}s
  *
 */
public class LexEdgeContent implements EdgeContent, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5865810013037527830L;

}
