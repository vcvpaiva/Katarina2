package sem.graph;


import java.io.Serializable;

/**
 * An interface defining the content that can be included on a {@link SemanticNode in addition the to the node label
 *
 */
public class NodeContent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2564008328836906160L;

}
