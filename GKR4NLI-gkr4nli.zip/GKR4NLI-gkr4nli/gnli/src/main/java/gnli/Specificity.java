package gnli;

public enum Specificity { SUBCLASS, SUPERCLASS, EQUALS, DISJOINT, NONE

}
