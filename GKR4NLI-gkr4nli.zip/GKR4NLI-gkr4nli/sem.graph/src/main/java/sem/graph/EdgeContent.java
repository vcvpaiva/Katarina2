package sem.graph;


/**
 * An interface defining the content that can be included on a {@link SemanticEdge} in addition the to the edge label
 *
 */
public interface EdgeContent {

}
