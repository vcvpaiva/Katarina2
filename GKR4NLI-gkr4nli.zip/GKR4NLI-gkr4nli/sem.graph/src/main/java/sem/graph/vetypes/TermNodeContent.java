package sem.graph.vetypes;

import java.io.Serializable;

import sem.graph.NodeContent;

/**
 * The {@link NodeContent} of a {@link TermNode}
 *
 */
public class TermNodeContent extends NodeContent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6298888883067719047L;

}
