package sem.graph.vetypes;

import java.io.Serializable;

import sem.graph.EdgeContent;


/**
 * Vanilla implementation of {@link EdgeContent}
 *
 */
public class DefaultEdgeContent implements EdgeContent, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5398523766152464511L;

}
