package sem.graph.vetypes;

import java.io.Serializable;

import sem.graph.EdgeContent;

/**
 * The {@link EdgeContent} for a {@link PropertyEdge}
 *
 */
public class PropertyEdgeContent implements EdgeContent, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3718732282571504990L;

}
